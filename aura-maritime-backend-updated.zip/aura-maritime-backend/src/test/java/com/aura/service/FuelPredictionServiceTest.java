package com.aura.service;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import com.aura.model.FuelType;
import com.aura.model.PredictionRequest;

class FuelPredictionServiceTest {
    @Test void calculatesFuelPredictionForKnownVessel(){
        FleetDataService data=new FleetDataService();
        FuelPredictionService service=new FuelPredictionService(data);
        PredictionRequest request=new PredictionRequest(); request.setVesselId("VESSEL-01"); request.setDistanceNM(1200);
        request.setCargoLoadPercent(80); request.setCruisingSpeedKnots(14); request.setFuelType(FuelType.LNG); request.setSeaConditionBeaufort(3);
        var result=service.predict(request);
        assertTrue(((Number)result.get("predictedFuelLiters")).doubleValue()>0);
        assertTrue(((Number)result.get("estimatedCostINR")).doubleValue()>0);
        assertNotNull(result.get("speedVsFuelCurve"));
    }
}

package com.aura.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.aura.model.RouteOption;
import com.aura.model.Vessel;

@Service
public class FleetDataService {
    private final List<Vessel> vessels = List.of(
        new Vessel("VESSEL-01","Vessel 01 (Oceanic Carrier)","Container Ship",12500,"LNG","In Transit",14,21,28.5,"JNPT Mumbai → Jebel Ali Dubai",85,3,0.96),
        new Vessel("VESSEL-02","Vessel 02 (Indus Pioneer)","Bulk Carrier",18000,"MGO","In Transit",15,20,34.2,"Singapore → Port of Chennai",92,5,0.91),
        new Vessel("VESSEL-03","Vessel 03 (Green Voyager)","LNG Tanker",9500,"METHANOL","Available",13,18,22.8,"Visakhapatnam → Port of Chittagong",70,2,0.98),
        new Vessel("VESSEL-04","Vessel 04 (Maritime Trader)","Cargo Vessel",14000,"HFO","In Transit",14.5,19,31.0,"Mundra → Port Said Egypt",88,7,0.88),
        new Vessel("VESSEL-05","Vessel 05 (Malabar Express)","Ro-Ro Carrier",6500,"LNG","Available",16,22,19.5,"Kochi → Port of Malé",60,1,0.99),
        new Vessel("VESSEL-06","Vessel 06 (Bengal Freighter)","Bulk Carrier",22000,"MGO","Maintenance",12,17,41.0,"Docked at Chennai Shipyard",0,9,0.84),
        new Vessel("VESSEL-07","Vessel 07 (Coromandel Coast)","Container Ship",16000,"LNG","Available",14.8,21,30.5,"Colombo → Port of Hambantota",75,4,0.94),
        new Vessel("VESSEL-08","Vessel 08 (Coastal Runner)","Cargo Vessel",11000,"MGO","Available",13.5,18,24.1,"Kochi → Port of Malé",68,3,0.95),
        new Vessel("VESSEL-09","Vessel 09 (Bay Navigator)","Ro-Ro Carrier",8500,"METHANOL","Available",15,20,21.0,"Visakhapatnam → Port of Chittagong",72,2,0.97),
        new Vessel("VESSEL-10","Vessel 10 (Eastern Star)","Bulk Carrier",20000,"HFO","In Transit",13.5,18,36.8,"Singapore → Port of Chennai",90,6,0.89)
    );
    private final List<RouteOption> routes = List.of(
        new RouteOption("R-101","JNPT Mumbai → Jebel Ali Dubai","JNPT, India","Dubai, UAE",1200,3,1.2),
        new RouteOption("R-102","Singapore → Port of Chennai","Singapore","Chennai, India",1580,4,1.8),
        new RouteOption("R-103","Visakhapatnam → Port of Chittagong","Visakhapatnam, India","Chittagong, Bangladesh",540,2,0.8),
        new RouteOption("R-104","Kochi → Port of Malé","Kochi, India","Malé, Maldives",420,3,1.0),
        new RouteOption("R-105","Mundra → Port Said Egypt","Mundra, India","Port Said, Egypt",2850,5,2.1),
        new RouteOption("R-106","Colombo → Port of Hambantota","Colombo, Sri Lanka","Hambantota, Sri Lanka",140,2,0.5)
    );
    public List<Vessel> getVessels(){return vessels;}
    public List<RouteOption> getRoutes(){return routes;}
    public Vessel findVessel(String id){return vessels.stream().filter(v -> v.getId().equalsIgnoreCase(id)).findFirst().orElseThrow(() -> new IllegalArgumentException("Unknown vesselId: " + id));}
    public RouteOption findRoute(String id){return routes.stream().filter(r -> r.getId().equalsIgnoreCase(id)).findFirst().orElseThrow(() -> new IllegalArgumentException("Unknown routeId: " + id));}
}

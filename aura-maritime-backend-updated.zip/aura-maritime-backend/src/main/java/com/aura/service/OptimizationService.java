package com.aura.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.aura.model.FuelType;
import com.aura.model.OptimizationRequest;
import com.aura.model.RouteOption;
import com.aura.model.Vessel;

@Service
public class OptimizationService {
    private final FleetDataService data;
    public OptimizationService(FleetDataService data){this.data=data;}

    public Map<String,Object> optimize(OptimizationRequest request) {
        var c=request.getConstraints();
        RouteOption route=data.findRoute(request.getRouteId()==null || request.getRouteId().isBlank()?"R-101":request.getRouteId());
        List<Vessel> candidates=new ArrayList<>();
        List<String> ids=c.getAvailableVesselIds();
        if(ids!=null && !ids.isEmpty()) for(String id:ids) { Vessel v=data.findVessel(id); if(!"Maintenance".equalsIgnoreCase(v.getStatus())) candidates.add(v); }
        else candidates.addAll(data.getVessels().stream().filter(v->!"Maintenance".equalsIgnoreCase(v.getStatus())).toList());
        if(candidates.isEmpty()) throw new IllegalArgumentException("No eligible vessels were supplied.");
        Vessel selected=candidates.stream().min((a,b)->Double.compare(score(a,route,c.getCargoDemandTons()),score(b,route,c.getCargoDemandTons()))).orElseThrow();
        double quantumSpeed=Math.max(8,Math.min(selected.getMaxSpeed(),selected.getCruisingSpeed()*0.94));
        double classicalSpeed=Math.max(8,Math.min(selected.getMaxSpeed(),selected.getCruisingSpeed()));
        Map<String,Object> result=new LinkedHashMap<>();
        result.put("classicalPlan",buildPlan(selected,route,c,classicalSpeed,"Classical Heuristic MILP"));
        result.put("quantumPlan",buildPlan(selected,route,c,quantumSpeed,"Quantum-Inspired QUBO Annealing"));
        result.put("notice","Both plans are deterministic heuristic comparisons for a student prototype. No MILP solver or QUBO/quantum annealing engine is executed.");
        return result;
    }
    private double score(Vessel v, RouteOption r, double demand){
        double load=Math.min(100,demand/Math.max(1,v.getCapacityDWT())*100);
        double rate=v.getBaseConsumptionRate()*Math.pow(v.getCruisingSpeed()/v.getCruisingSpeed(),2.75)*(0.65+0.35*load/100.0)*(1+0.045*Math.max(0,r.getSeaConditionBeaufort()-1))/Math.max(0.7,v.getEfficiencyRating());
        return rate*r.getDistanceNM()*FuelPredictionService.price(FuelType.valueOf(v.getFuelType()));
    }
    private Map<String,Object> buildPlan(Vessel vessel, RouteOption route, OptimizationRequest.Constraints c, double speed, String methodology){
        double load=Math.min(100, c.getCargoDemandTons()/Math.max(1,vessel.getCapacityDWT())*100);
        double speedRatio=Math.pow(speed/vessel.getCruisingSpeed(),2.75);
        double rate=vessel.getBaseConsumptionRate()*speedRatio*(0.65+0.35*load/100.0)*(1+0.045*Math.max(0,route.getSeaConditionBeaufort()-1))/Math.max(0.7,vessel.getEfficiencyRating());
        double fuel=Math.round(rate*route.getDistanceNM());
        FuelType type=FuelType.valueOf(vessel.getFuelType());
        double cost=fuel*FuelPredictionService.price(type);
        double co2=FuelPredictionService.round2(fuel*FuelPredictionService.emission(type)/1000.0);
        double hours=FuelPredictionService.round1(route.getDistanceNM()/speed);
        Map<String,Object> checks=Map.of("cargoDemand",vessel.getCapacityDWT()>=c.getCargoDemandTons(),"capacity",vessel.getCapacityDWT()>=c.getCargoDemandTons(),"schedule",hours<=c.getScheduleMaxHours()+c.getMaxDelayHours(),"fuelBudget",cost/100000.0<=c.getFuelBudgetLakhINR());
        Map<String,Object> plan=new LinkedHashMap<>(); plan.put("vessel",vessel); plan.put("assignedRoute",route.getName()); plan.put("recommendedSpeedKnots",FuelPredictionService.round2(speed));
        plan.put("fuelType",vessel.getFuelType()); plan.put("cargoCarriedTons",Math.min(c.getCargoDemandTons(),vessel.getCapacityDWT()));
        plan.put("estimatedFuelLiters",fuel); plan.put("estimatedCostLakhINR",FuelPredictionService.round2(cost/100000.0));
        plan.put("estimatedCO2Tonnes",co2); plan.put("expectedArrivalTimeHours",hours); plan.put("constraintsSatisfied",checks); plan.put("methodology",methodology); return plan;
    }
}

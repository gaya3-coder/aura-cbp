package com.aura.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.aura.model.FuelType;
import com.aura.model.PredictionRequest;
import com.aura.model.Vessel;

@Service
public class FuelPredictionService {
    private static final Map<FuelType, Double> PRICES = new LinkedHashMap<>();
    private static final Map<FuelType, Double> EMISSIONS = new LinkedHashMap<>();
    static {
        PRICES.put(FuelType.LNG,78.50); PRICES.put(FuelType.MGO,94.20); PRICES.put(FuelType.METHANOL,68.00);
        PRICES.put(FuelType.HFO,62.40); PRICES.put(FuelType.HYDROGEN,110.00); PRICES.put(FuelType.AMMONIA,82.00);
        EMISSIONS.put(FuelType.LNG,1.95); EMISSIONS.put(FuelType.MGO,2.68); EMISSIONS.put(FuelType.METHANOL,1.38);
        EMISSIONS.put(FuelType.HFO,3.11); EMISSIONS.put(FuelType.HYDROGEN,0.05); EMISSIONS.put(FuelType.AMMONIA,0.12);
    }
    private final FleetDataService data;
    public FuelPredictionService(FleetDataService data){this.data=data;}

    public Map<String,Object> predict(PredictionRequest request) {
        Vessel vessel=data.findVessel(request.getVesselId());
        if(request.getCruisingSpeedKnots()>vessel.getMaxSpeed()) throw new IllegalArgumentException("Cruising speed cannot exceed vessel maxSpeed of " + vessel.getMaxSpeed() + " knots");
        double speedRatio=Math.pow(request.getCruisingSpeedKnots()/vessel.getCruisingSpeed(),2.75);
        double loadFactor=0.65+0.35*(request.getCargoLoadPercent()/100.0);
        double weatherFactor=1+0.045*Math.max(0,request.getSeaConditionBeaufort()-1);
        double engineFactor=1/Math.max(0.7,vessel.getEfficiencyRating());
        double fuelRate=vessel.getBaseConsumptionRate()*speedRatio*loadFactor*weatherFactor*engineFactor;
        double fuel=Math.round(fuelRate*request.getDistanceNM());
        double price=request.getCustomFuelPrice()!=null && request.getCustomFuelPrice()>0 ? request.getCustomFuelPrice() : PRICES.get(request.getFuelType());
        double cost=Math.round(fuel*price);
        double co2=round2(fuel*EMISSIONS.get(request.getFuelType())/1000.0);
        double hours=round1(request.getDistanceNM()/request.getCruisingSpeedKnots());
        ArrayList<Map<String,Object>> curve=new ArrayList<>();
        int max=(int)Math.min(22,vessel.getMaxSpeed());
        for(int speed=10;speed<=max;speed++) {
            double rate=vessel.getBaseConsumptionRate()*Math.pow(speed/vessel.getCruisingSpeed(),2.75)*loadFactor*weatherFactor*engineFactor;
            Map<String,Object> point=new LinkedHashMap<>(); point.put("speed",speed); point.put("fuelLiters",Math.round(rate*request.getDistanceNM())); point.put("travelTimeHours",round1(request.getDistanceNM()/speed)); curve.add(point);
        }
        Map<String,Object> breakdown=Map.of("speedPenaltyPercent",Math.round((speedRatio-1)*100),"loadPenaltyPercent",Math.round((loadFactor-1)*100),"weatherPenaltyPercent",Math.round((weatherFactor-1)*100));
        Map<String,Object> result=new LinkedHashMap<>(); result.put("vessel",vessel); result.put("predictedFuelLiters",fuel); result.put("estimatedCostINR",cost);
        result.put("estimatedCO2Tonnes",co2); result.put("estimatedTravelTimeHours",hours); result.put("fuelRatePerNM",round2(fuelRate));
        result.put("efficiencyBreakdown",breakdown); result.put("speedVsFuelCurve",curve); result.put("notice","Prototype estimate based on configured demo assumptions; not a real-world or certified marine-engine prediction.");
        return result;
    }
    public static double price(FuelType type){return PRICES.get(type);}
    public static double emission(FuelType type){return EMISSIONS.get(type);}
    public static double round2(double n){return Math.round(n*100.0)/100.0;}
    public static double round1(double n){return Math.round(n*10.0)/10.0;}
}

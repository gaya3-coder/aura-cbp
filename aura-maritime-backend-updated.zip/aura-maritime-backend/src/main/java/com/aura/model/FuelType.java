package com.aura.model;

public enum FuelType {
    LNG, MGO, METHANOL, HFO, HYDROGEN, AMMONIA
}

package com.aura.model;

import java.util.ArrayList;
import java.util.List;
import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

public class OptimizationRequest {
    @NotNull @Valid private Objectives objectives = new Objectives();
    @NotNull @Valid private Constraints constraints = new Constraints();
    private String routeId = "R-101";
    public Objectives getObjectives(){return objectives;} public Constraints getConstraints(){return constraints;}
    public String getRouteId(){return routeId;} public void setObjectives(Objectives v){objectives=v;}
    public void setConstraints(Constraints v){constraints=v;} public void setRouteId(String v){routeId=v;}
    public static class Objectives {
        private boolean minimizeFuel=true, minimizeCost=true, minimizeCO2=true;
        public boolean isMinimizeFuel(){return minimizeFuel;} public boolean isMinimizeCost(){return minimizeCost;}
        public boolean isMinimizeCO2(){return minimizeCO2;} public void setMinimizeFuel(boolean v){minimizeFuel=v;}
        public void setMinimizeCost(boolean v){minimizeCost=v;} public void setMinimizeCO2(boolean v){minimizeCO2=v;}
    }
    public static class Constraints {
        @DecimalMin("0.0") private double cargoDemandTons=5000;
        @DecimalMin("1.0") private double scheduleMaxHours=100;
        @DecimalMin("0.0") private double fuelBudgetLakhINR=100;
        @DecimalMin("0.0") private double maxDelayHours=12;
        private List<String> availableVesselIds = new ArrayList<>(List.of("VESSEL-01"));
        public double getCargoDemandTons(){return cargoDemandTons;} public double getScheduleMaxHours(){return scheduleMaxHours;}
        public double getFuelBudgetLakhINR(){return fuelBudgetLakhINR;} public double getMaxDelayHours(){return maxDelayHours;}
        public List<String> getAvailableVesselIds(){return availableVesselIds;}
        public void setCargoDemandTons(double v){cargoDemandTons=v;} public void setScheduleMaxHours(double v){scheduleMaxHours=v;}
        public void setFuelBudgetLakhINR(double v){fuelBudgetLakhINR=v;} public void setMaxDelayHours(double v){maxDelayHours=v;}
        public void setAvailableVesselIds(List<String> v){availableVesselIds=v;}
    }
}

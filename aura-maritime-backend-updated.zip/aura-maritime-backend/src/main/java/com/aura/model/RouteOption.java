package com.aura.model;

public class RouteOption {
    private String id, name, origin, destination;
    private double distanceNM;
    private int seaConditionBeaufort;
    private double currentKnots;
    public RouteOption(String id, String name, String origin, String destination, double distanceNM, int seaConditionBeaufort, double currentKnots) {
        this.id=id; this.name=name; this.origin=origin; this.destination=destination; this.distanceNM=distanceNM;
        this.seaConditionBeaufort=seaConditionBeaufort; this.currentKnots=currentKnots;
    }
    public String getId(){return id;} public String getName(){return name;} public String getOrigin(){return origin;}
    public String getDestination(){return destination;} public double getDistanceNM(){return distanceNM;}
    public int getSeaConditionBeaufort(){return seaConditionBeaufort;} public double getCurrentKnots(){return currentKnots;}
}

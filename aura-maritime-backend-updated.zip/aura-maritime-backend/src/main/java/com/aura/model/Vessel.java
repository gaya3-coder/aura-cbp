package com.aura.model;

public class Vessel {
    private String id;
    private String name;
    private String type;
    private double capacityDWT;
    private String fuelType;
    private String status;
    private double cruisingSpeed;
    private double maxSpeed;
    private double baseConsumptionRate;
    private String currentRoute;
    private double cargoLoad;
    private int engineAgeYears;
    private double efficiencyRating;

    public Vessel(String id, String name, String type, double capacityDWT, String fuelType, String status,
                  double cruisingSpeed, double maxSpeed, double baseConsumptionRate, String currentRoute,
                  double cargoLoad, int engineAgeYears, double efficiencyRating) {
        this.id=id; this.name=name; this.type=type; this.capacityDWT=capacityDWT; this.fuelType=fuelType;
        this.status=status; this.cruisingSpeed=cruisingSpeed; this.maxSpeed=maxSpeed;
        this.baseConsumptionRate=baseConsumptionRate; this.currentRoute=currentRoute; this.cargoLoad=cargoLoad;
        this.engineAgeYears=engineAgeYears; this.efficiencyRating=efficiencyRating;
    }
    public String getId(){return id;} public String getName(){return name;} public String getType(){return type;}
    public double getCapacityDWT(){return capacityDWT;} public String getFuelType(){return fuelType;}
    public String getStatus(){return status;} public double getCruisingSpeed(){return cruisingSpeed;}
    public double getMaxSpeed(){return maxSpeed;} public double getBaseConsumptionRate(){return baseConsumptionRate;}
    public String getCurrentRoute(){return currentRoute;} public double getCargoLoad(){return cargoLoad;}
    public int getEngineAgeYears(){return engineAgeYears;} public double getEfficiencyRating(){return efficiencyRating;}
}

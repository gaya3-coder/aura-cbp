package com.aura.model;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class PredictionRequest {
    @NotBlank private String vesselId;
    @DecimalMin("1.0") @DecimalMax("10000.0") private double distanceNM;
    @DecimalMin("0.0") @DecimalMax("100.0") private double cargoLoadPercent;
    @DecimalMin("1.0") @DecimalMax("35.0") private double cruisingSpeedKnots;
    @NotNull private FuelType fuelType;
    @DecimalMin("1.0") @DecimalMax("12.0") private int seaConditionBeaufort;
    @DecimalMin("0.0") private Double customFuelPrice;
    public String getVesselId(){return vesselId;} public double getDistanceNM(){return distanceNM;}
    public double getCargoLoadPercent(){return cargoLoadPercent;} public double getCruisingSpeedKnots(){return cruisingSpeedKnots;}
    public FuelType getFuelType(){return fuelType;} public int getSeaConditionBeaufort(){return seaConditionBeaufort;}
    public Double getCustomFuelPrice(){return customFuelPrice;}
    public void setVesselId(String v){vesselId=v;} public void setDistanceNM(double v){distanceNM=v;}
    public void setCargoLoadPercent(double v){cargoLoadPercent=v;} public void setCruisingSpeedKnots(double v){cruisingSpeedKnots=v;}
    public void setFuelType(FuelType v){fuelType=v;} public void setSeaConditionBeaufort(int v){seaConditionBeaufort=v;}
    public void setCustomFuelPrice(Double v){customFuelPrice=v;}
}

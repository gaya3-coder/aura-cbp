package com.aura.controller;

import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import jakarta.validation.Valid;
import com.aura.model.OptimizationRequest;
import com.aura.model.PredictionRequest;
import com.aura.service.FleetDataService;
import com.aura.service.FuelPredictionService;
import com.aura.service.OptimizationService;

@RestController
@RequestMapping("/api/v1")
public class ApiController {
    private final FleetDataService data;
    private final FuelPredictionService prediction;
    private final OptimizationService optimization;
    public ApiController(FleetDataService data, FuelPredictionService prediction, OptimizationService optimization){this.data=data;this.prediction=prediction;this.optimization=optimization;}
    @GetMapping("/health") public Map<String,Object> health(){return Map.of("status","UP","service","AURA Maritime Analytics API","version","1.0.0");}
    @GetMapping("/fleet/vessels") public Map<String,Object> vessels(){return Map.of("count",data.getVessels().size(),"items",data.getVessels());}
    @GetMapping("/routes") public Map<String,Object> routes(){return Map.of("count",data.getRoutes().size(),"items",data.getRoutes());}
    @PostMapping("/predictions/fuel") public Map<String,Object> predict(@Valid @RequestBody PredictionRequest request){return prediction.predict(request);}
    @PostMapping("/fleet/optimize") public Map<String,Object> optimize(@Valid @RequestBody OptimizationRequest request){return optimization.optimize(request);}
    @GetMapping("/config/fuels") public Map<String,Object> fuels(){
        Map<String,Object> items=new LinkedHashMap<>();
        for(var type:com.aura.model.FuelType.values()) items.put(type.name(),Map.of("defaultPrice",FuelPredictionService.price(type),"emissionFactorKgPerLiterEquivalent",FuelPredictionService.emission(type)));
        return Map.of("unitNote","These are configurable demo assumptions using liter-equivalent values; validate units and factors before real-world use.","items",items);
    }
}

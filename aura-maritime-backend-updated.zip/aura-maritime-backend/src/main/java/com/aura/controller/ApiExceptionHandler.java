package com.aura.controller;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ApiExceptionHandler {
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String,Object>> badInput(IllegalArgumentException ex){return response(HttpStatus.BAD_REQUEST,ex.getMessage());}
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String,Object>> invalidFields(MethodArgumentNotValidException ex){
        Map<String,String> fields=new LinkedHashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(e->fields.put(e.getField(),e.getDefaultMessage()));
        Map<String,Object> body=new LinkedHashMap<>(); body.put("timestamp",Instant.now().toString()); body.put("status",400); body.put("error","Validation failed"); body.put("fields",fields);
        return ResponseEntity.badRequest().body(body);
    }
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Map<String,Object>> unreadable(HttpMessageNotReadableException ex){return response(HttpStatus.BAD_REQUEST,"Invalid JSON or unsupported fuelType. Use LNG, MGO, METHANOL, HFO, HYDROGEN, or AMMONIA.");}
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String,Object>> serverError(Exception ex){return response(HttpStatus.INTERNAL_SERVER_ERROR,"Unexpected server error. Check backend logs for details.");}
    private ResponseEntity<Map<String,Object>> response(HttpStatus status,String message){Map<String,Object> body=new LinkedHashMap<>(); body.put("timestamp",Instant.now().toString()); body.put("status",status.value()); body.put("error",status.getReasonPhrase()); body.put("message",message); return ResponseEntity.status(status).body(body);}
}

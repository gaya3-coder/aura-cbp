import {
  calculateFuelPrediction,
  runFleetOptimization,
  PredictionInput,
  PredictionResult,
  OptimizationObjectives,
  OptimizationConstraints,
  OptimizedFleetPlan,
} from './mathEngine';
import { DEMO_VESSELS } from './demoData';

/**
 * Backend base URL. Override with VITE_API_URL in a .env file
 * (see .env.example). Defaults to the local Spring Boot server.
 */
export const API_BASE_URL: string =
  ((import.meta as any).env?.VITE_API_URL as string | undefined)?.replace(/\/+$/, '') ||
  'http://localhost:8080';

const TIMEOUT_MS = 4000;

export type DataSource = 'backend' | 'local';

async function request<T>(path: string, body: unknown, signal?: AbortSignal): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  signal?.addEventListener('abort', () => controller.abort());
  try {
    const res = await fetch(`${API_BASE_URL}/api/v1${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return (await res.json()) as T;
  } finally {
    clearTimeout(timer);
  }
}

/** Fuel prediction from the backend; falls back to the local engine if unreachable. */
export async function fetchFuelPrediction(
  input: PredictionInput,
  signal?: AbortSignal
): Promise<{ result: PredictionResult; source: DataSource }> {
  try {
    const result = await request<PredictionResult>('/predictions/fuel', input, signal);
    return { result, source: 'backend' };
  } catch (err) {
    if (signal?.aborted) throw err;
    return { result: calculateFuelPrediction(input), source: 'local' };
  }
}

/** Fleet optimization from the backend; falls back to the local engine if unreachable. */
export async function fetchFleetOptimization(
  objectives: OptimizationObjectives,
  constraints: OptimizationConstraints,
  routeId = 'R-101'
): Promise<{
  result: { classicalPlan: OptimizedFleetPlan; quantumPlan: OptimizedFleetPlan };
  source: DataSource;
}> {
  try {
    const raw = await request<{ classicalPlan: OptimizedFleetPlan; quantumPlan: OptimizedFleetPlan }>(
      '/fleet/optimize',
      { routeId, objectives, constraints }
    );
    // Backend vessels have no image URL; restore it from the local registry.
    const withImage = (p: OptimizedFleetPlan): OptimizedFleetPlan => ({
      ...p,
      vessel: { ...(DEMO_VESSELS.find(v => v.id === p.vessel.id) || ({} as any)), ...p.vessel },
    });
    return {
      result: { classicalPlan: withImage(raw.classicalPlan), quantumPlan: withImage(raw.quantumPlan) },
      source: 'backend',
    };
  } catch {
    return { result: runFleetOptimization(objectives, constraints), source: 'local' };
  }
}
